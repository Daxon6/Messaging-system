<?php
session_start();
require_once __DIR__ . '/../vendor/autoload.php';

use App\Models\User;

if (!isset($_SESSION['user_id'])) {
    header('Location: prijava.php');
    exit();
}

$users = User::where('id', '!=', $_SESSION['user_id'])->get();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send Message</title>
    <link rel="stylesheet" href="stilovi.css">
</head>
<body>
<div class="container">
    <h2>Send a Message</h2>
    <form action="logika/porukeLogika.php" method="POST"">

        <input type="text" name="title" placeholder="Title" required>

        <textarea name="body" placeholder="Message Body" maxlength="160" required></textarea>

        <select name="recipient_id" required>
            <option value="">-- Select a User --</option>
            <?php foreach ($users as $user): ?>
                <option value="<?= $user->id ?>">
                    <?= htmlspecialchars($user->username) ?> (<?= htmlspecialchars($user->email) ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <div>
            <label><input type="radio" name="urgency" value="urgent" required> Urgent</label>
            <label><input type="radio" name="urgency" value="normal" required> Not Urgent</label>
        </div>

        <button type="submit" id="register">Send Message</button>
    </form>
</div>

<p><a href="korisnik.php">Profile</a></p>
</body>
</html>
