<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';

use App\Models\User;

if (!isset($_SESSION['user_id'])) {
    header('Location: ../prijava.php');
    exit();
}

$title = $_POST['title'];
$body = $_POST['body'];
$recipientId = $_POST['recipient_id'];
$urgency = $_POST['urgency'];

$sender = User::where('id', $_SESSION['user_id'])->first();
$recipient = User::where('id', $recipientId)->first();

$_SESSION['mail'] = [
    'from_email' => $sender->email,
    'from_name' => $sender->username,
    'to_email' => $recipient->email,
    'to_name' => $recipient->username,
    'subject' => $urgency === 'urgent' ? '[URGENT] ' . $title : $title,
    'body' => nl2br(htmlspecialchars($body))
];

header('Location: posaljiMejlLogika.php');
exit();
